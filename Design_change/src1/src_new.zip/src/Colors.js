const Colors = {
    navbarBackgroundColor: '#ff9500',
    statusBarColor: '#233240'
};

export default Colors;